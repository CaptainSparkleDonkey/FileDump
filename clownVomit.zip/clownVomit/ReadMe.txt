
Theres nothing specail about this interface other than recorded macros of standard functions within z brush. Ive only made custom icons to scale down some of the lengthy text buttons, add a toggle here n there and color coded my interface for rapidly finding tools/functions I need often.

////////////////////////////////////////////////////////////////////////////////////
Unzip "ClownVomit" folder inside your "C:\Program Files\Pixologic\ZBrush 2022\ZStartup\Macros" folder

when you unzip "ClownVomit.zip" into your macros directory you will have a"ClownVomit" folder with a sub folder called "ClownVomit" DO NOT CHANGE THIS or nothing work.


"CV1" is a standard custom palette. it contains all the brush/stroke/masking functions I use most frequently.

Startup hotkeys (if you want to use them)
1-8 = common brushes (standard, move, damnStandard,etc) "7" is "penWet" which Ive also added 

Alt+ x = solo mode
shift+ f = poly frame
Shift+ v = transparent ghost mode On/Off
cntrl+alt+z = grow visible /hidden
cntrl+alt+x = shrink visible/hidden
alt+shift+z = grow mask
alt+shift+x = shrink mask

Use at your own risk. Store a backup of your config before using any of this.